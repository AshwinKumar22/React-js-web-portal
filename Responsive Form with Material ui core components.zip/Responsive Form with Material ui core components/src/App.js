import React, { Component } from "react";
import MuiThemeProvider from "material-ui/styles/MuiThemeProvider";
import injectTapEventPlugin from "react-tap-event-plugin";
import orderBy from "lodash/orderBy";



//import logo from "./logo.svg";
//import "./App.css";
import Form from "./Form";
import Table from "./Table";
import GridItem from "./components/Grid/GridItem.jsx";

import Card from "./components/Card/Card.jsx";
import CardHeader from "./components/Card/CardHeader.jsx";

import CardBody from "./components/Card/CardBody.jsx";

import withStyles from "@material-ui/core/styles/withStyles";
const styles = {
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none"
  }
};

injectTapEventPlugin();

const invertDirection = {
  asc: "desc",
  desc: "asc"
};
class App extends Component {
  state = {
    data: [],
    editIdx: -1,
    columnToSort: "",
    sortDirection: "desc",
    query: "",
    columnToQuery: "firstName"
  };
  handleRemove = i => {
    this.setState(state => ({
      data: state.data.filter((row, j) => j !== i)
    }));
  };

  startEditing = i => {
    this.setState({ editIdx: i });
  };

  stopEditing = () => {
    this.setState({ editIdx: -1 });
  };

  handleChange = (e, name, i) => {
    const { value } = e.target;
    this.setState(state => ({
      data: state.data.map(
        (row, j) => (j === i ? { ...row, [name]: value } : row)
      )
    }));
  };

  handleSort = columnName => {
    this.setState(state => ({
      columnToSort: columnName,
      sortDirection:
        state.columnToSort === columnName
          ? invertDirection[state.sortDirection]
          : "asc"
    }));
  };

  render() {
    const { classes } =this.props;
    return (
      <MuiThemeProvider>
        <div className="App">
          <Form
            onAdd={submission =>
              this.setState({
                data: [...this.state.data, submission]
              })
            }
          />
          <GridItem xs={12} sm={12} md={12}>
          <Card>
          <GridItem xs={12} sm={12} md={10}><CardHeader color="primary">
              <h4 className={classes.cardTitleWhite}>DATA GRID</h4>
              
            </CardHeader></GridItem>
            <CardBody>
            <Table
            handleSort={this.handleSort}
            handleRemove={this.handleRemove}
            startEditing={this.startEditing}
            editIdx={this.state.editIdx}
            stopEditing={this.stopEditing}
            handleChange={this.handleChange}
            columnToSort={this.state.columnToSort}
            sortDirection={this.state.sortDirection}
            data={orderBy(
              this.state.data,
              this.state.columnToSort,
              this.state.sortDirection
            )}
            
            header={[
              {
                name: "Sap Material Code",   
                prop: "Sapmaterialcode"
              },
              
              {
                name: "REQD.QTY",
                prop: "Reqdqty"
              },
              {
                name: "Description Of Material",
                prop: "Descriptionofmaterial"
              },
              {
                name: "UOM",
                prop: "UOM"
              },
              {
                name: "TYPE OF REQ",   
                prop: "Typeofreq"
              }
              
            ]}
          />
          </CardBody>
          </Card></GridItem>
        </div>
        
      </MuiThemeProvider>
      
         
    );
  }
}

export default withStyles(styles)(App);
