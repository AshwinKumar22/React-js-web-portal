import React from "react";
import TextField from "material-ui/TextField";
import RaisedButton from "material-ui/RaisedButton";
import GridItem from "../components/Grid/GridItem.jsx";
import GridContainer from "../components/Grid/GridContainer.jsx";
import Card from "../components/Card/Card.jsx";
import CardHeader from "../components/Card/CardHeader.jsx";
//import CardAvatar from "../components/Card/CardAvatar.jsx";
import CardBody from "../components/Card/CardBody.jsx";
import CardFooter from "../components/Card/CardFooter.jsx";
import withStyles from "@material-ui/core/styles/withStyles";
const styles = {
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none"
  }
};


 class Form extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    WorkOrderNUmber: "",
    WorkOrderNUmberError: "",
    EmployeeNumber: "",
    EmployeeNumberError: "",
    ProjectNumber: "",
    ProjectNumberError: "",
    LocationArea: "",
    LocationAreaError: "",
    Dept: "",
    DeptError: "",
    Sapmaterialcode: "",
    SapmaterialcodeError: "",
    Returnedqty: "",
    ReturnedqtyError: "",
    UOM: "",
    UOMError: "",
    Unit: "",
    UnitError: "",
    Descriptionofmaterial:"",
    DescriptionofmaterialError :"",
  }};

  change = e => {
    // this.props.onChange({ [e.target.name]: e.target.value });
    this.setState({
      [e.target.name]: e.target.value
    });
  };

  validate = () => {
    let isError = false;
    const errors = {
      WorkOrderNUmberError: "",
      EmployeeNumberError: "",
      ProjectNumberError: "",
      DeptError: "",
      UOMError: "",
      SapmaterialcodeError: "",
      ReturnedqtyError: "",
      UnitError: "",
      DescriptionofmaterialError :"",
    };

    

    this.setState({
      ...this.state,
      ...errors
    });

    return isError;
  };

  onAdd = e => {
    
    e.preventDefault();
    
    const err = this.validate();
    if (!err) {
      this.props.onAdd(this.state);
      // clear form
      this.setState({
        eWorkOrderNUmber: "",
        eWorkOrderNUmberError: "",
        eEmployeeNumber: "",
        EmployeeNumberError: "",
        eProjectNumber: "",
        ProjectNumberError: "",
        eLocationArea: "",
        LocationAreaError: "",
        eDept: "",
        DeptError: "",
        eSapmaterialcode: "",
        SapmaterialcodeError: "",
        eReqdqty: "",
        ReqdqtyError: "",
        eUOM: "",
        eUOMError: "",
    eTypeofreq: "",
    TypeofreqError: "",
    eDescriptionofmaterial:"",
    DescriptionofmaterialError :"",
      });
    }
  };

  onSubmit = e => {
    
    e.preventDefault();
    const { WorkOrderNUmber, EmployeeNumber,ProjectNumber,LocationArea,Dept,Sapmaterialcode,
      Returnedqty,UOM,Unit,Descriptionofmaterial } = this.state
    alert(`Your state values: \n 
    WorkOrderNUmber: ${WorkOrderNUmber} \n 
    EmployeeNumber: ${EmployeeNumber}\n 
    ProjectNumber:${ProjectNumber}\n  
    LocationArea:${LocationArea}\n 
    Dept:${Dept}\n 
    Sapmaterialcode:${Sapmaterialcode}\n 
    Returnedqty:${Returnedqty}\n 
    UOM:${UOM}\n 
    Unit:${Unit}\n 
    Descriptionofmaterial:${Descriptionofmaterial}\n `)
    
    const err = this.validate();
    if (!err) {
      this.props.onAdd(this.state);
      // clear form
      this.setState({
        WorkOrderNUmber: "",
        WorkOrderNUmberError: "",
        EmployeeNumber: "",
        EmployeeNumberError: "",
        ProjectNumber: "",
        ProjectNumberError: "",
        LocationArea: "",
        LocationAreaError: "",
        Dept: "",
        DeptError: "",
        Sapmaterialcode: "",
        SapmaterialcodeError: "",
        Returnedqty: "",
        ReturnedqtyError: "",
        UOM: "",
        UOMError: "",
        Unit: "",
        UnitError: "",
        Descriptionofmaterial:"",
        DescriptionofmaterialError :"",
      });
    }
  };

  render() {
    const { classes } =this.props;
    return (
      <form>

            
        
         <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
          <GridItem xs={12} sm={12} md={10}><CardHeader color="primary">

              <h4 className={classes.cardTitleWhite}>MRV</h4>
              
            </CardHeader> </GridItem>
            <CardBody>
              <GridContainer>
                <GridItem xs={12} sm={12} md={4}>
        <TextField
          name="WorkOrderNUmber"
          hintText="WorkOrderNUmber"
          floatingLabelText="Work Order NUmber"
          value={this.state.WorkOrderNUmber}
          onChange={e => this.change(e)}
          errorText={this.state.WorkOrderNUmberError}
          floatingLabelFixed
        />
        </GridItem>
        <GridItem xs={12} sm={12} md={4}>
        <TextField
          name="EmployeeNumber"
          hintText="EmployeeNumber"
          floatingLabelText="Employee Number"
          value={this.state.EmployeeNumber}
          onChange={e => this.change(e)}
          errorText={this.state.EmployeeNumberError}
          floatingLabelFixed
        />
       </GridItem>
       <GridItem xs={12} sm={12} md={4}>
        <TextField
          name="ProjectNumber"
          hintText="ProjectNumber"
          floatingLabelText="Project Number"
          value={this.state.ProjectNumber}
          onChange={e => this.change(e)}
          errorText={this.state.ProjectNumberError}
          floatingLabelFixed
        />
        </GridItem>
        </GridContainer>
        <GridContainer>
                <GridItem xs={12} sm={12} md={4}>
        <TextField
          name="LocationArea"
          hintText="LocationArea"
          floatingLabelText="Location/Area"
          value={this.state.LocationArea}
          onChange={e => this.change(e)}
          errorText={this.state.LocationAreaError}
          floatingLabelFixed
        />
        </GridItem>
        <GridItem xs={12} sm={12} md={4}>
        <TextField
          name="Dept"
          hintText="Dept"
          floatingLabelText="Dept"
          value={this.state.Dept}
          onChange={e => this.change(e)}
          errorText={this.state.DeptError}
          type="text"
          floatingLabelFixed
        />
        </GridItem>
        </GridContainer>
        
        
            </CardBody>
            
        </Card>
        </GridItem>
        </GridContainer>
        
        <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card >
        <GridItem xs={12} sm={12} md={10}><CardHeader plain color="primary">
            <h4 className={classes.cardTitleWhite}>
              MRV Selection
            </h4>
            
          </CardHeader></GridItem>
          <CardBody>
          <GridContainer>
                <GridItem xs={12} sm={12} md={4}>
        <TextField
          name="Sapmaterialcode"
          hintText="Sapmaterialcode"
          floatingLabelText="Sap Material Code"
          value={this.state.Sapmaterialcode}
          onChange={e => this.change(e)}
          errorText={this.state.SapmaterialcodeError}
          type="text"
          floatingLabelFixed
        />
         </GridItem>
         <GridItem xs={12} sm={12} md={4}>
         <TextField
          name="Returnedqty"
          hintText="quantity"
          floatingLabelText="Returned.Qty"
          value={this.state.Returnedqty}
          onChange={e => this.change(e)}
          errorText={this.state.ReturnedqtyError}
          type="text"
          floatingLabelFixed
        />
         </GridItem>
         <GridItem xs={12} sm={12} md={4}>
         <TextField
          name="Descriptionofmaterial"
          hintText="Descriptionofmaterial"
          floatingLabelText="Description Of Material"
          value={this.state.Descriptionofmaterial}
          onChange={e => this.change(e)}
          errorText={this.state.DescriptionofmaterialError}
          type="text"
          floatingLabelFixed
        />
         </GridItem>
         
         
         </GridContainer>
              <GridContainer>
                <GridItem xs={12} sm={12} md={4}>
         <TextField
          name="UOM"
          hintText="UOM"
          floatingLabelText="UOM"
          value={this.state.UOM}
          onChange={e => this.change(e)}
          errorText={this.state.UOMError}
          type="text"
          floatingLabelFixed
        />
         </GridItem>
         <GridItem xs={12} sm={12} md={4}>
         <TextField
          name="Unit"
          hintText="TYPE OF REQ"
          floatingLabelText="Unit"
          value={this.state.Unit}
          onChange={e => this.change(e)}
          errorText={this.state.UnitError}
          type="text"
          floatingLabelFixed
        />
        </GridItem>
        
         </GridContainer>
          </CardBody>
          <CardFooter>
            <GridItem xs={12} sm={12} md={4}><RaisedButton label="Submit" onClick={e => this.onSubmit(e)} primary /></GridItem><GridItem xs={12} sm={12} md={4}>
         <RaisedButton label="Add" onClick={e => this.onAdd(e)} primary /></GridItem>
        </CardFooter>
        </Card>
      </GridItem>
    </GridContainer>
        
       
       
      </form>
    );
  }
}
export default withStyles(styles)(Form);