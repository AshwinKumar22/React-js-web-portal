// @material-ui/icons
import Dashboard from "@material-ui/icons/Dashboard";

// core components/views for Admin layout
import App from "./App.js";
import MRV from "./mrv/MRV.js";


// core components/views for RTL layout


const dashboardRoutes = [
  {
    path: "/App",
    name: "MIV",
    //rtlName: "لوحة القيادة",
    icon: Dashboard,
    component: App,
    layout: "/admin"
  },
  {
    path: "/MRV",
    name: "MRV",
    //rtlName: "لوحة القيادة",
    icon: Dashboard,
    component: MRV,
    layout: "/admin"
  }
];

export default dashboardRoutes;
